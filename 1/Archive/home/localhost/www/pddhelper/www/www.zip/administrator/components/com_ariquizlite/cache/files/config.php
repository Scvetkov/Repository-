<?php
if (!isset($GLOBALS['_ariQuizConfig'])) $GLOBALS['_ariQuizConfig'] = array (
  'Version' => '1.2.7',
  'FLang' => '19',
  'BLang' => '18',
);
?>